var $ = function(id) { return document.getElementById(id); };

$('content').innerText = '** content from script!';
