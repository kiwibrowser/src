
// trivial change for version 0.8

var hello = document.createElement("div");
hello.innerText = "hello world";
document.body.insertBefore(hello, document.body.firstChild);
